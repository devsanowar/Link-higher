<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SmartSolutionFeature extends Model
{
    protected $guarded = ['id'];
}
