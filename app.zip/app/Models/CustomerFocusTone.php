<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CustomerFocusTone extends Model
{
    protected $guarded = ["id"];
}
