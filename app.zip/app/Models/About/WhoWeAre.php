<?php

namespace App\Models\About;

use Illuminate\Database\Eloquent\Model;

class WhoWeAre extends Model
{
    protected $guarded = ["id"];
}
