<?php

namespace App\Models\About;

use Illuminate\Database\Eloquent\Model;

class MissionVision extends Model
{
    protected $guarded = ["id"];
}
