<?php

namespace App\Models\About;

use Illuminate\Database\Eloquent\Model;

class AboutUs extends Model
{
    protected $guarded = ['id'];
}
